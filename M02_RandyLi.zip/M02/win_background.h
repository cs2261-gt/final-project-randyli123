
//{{BLOCK(win_background)

//======================================================================
//
//	win_background, 256x256@4, 
//	+ palette 256 entries, not compressed
//	+ 52 tiles (t|f|p reduced) not compressed
//	+ regular map (in SBBs), not compressed, 32x32 
//	Total size: 512 + 1664 + 2048 = 4224
//
//	Time-stamp: 2020-04-05, 16:10:37
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_WIN_BACKGROUND_H
#define GRIT_WIN_BACKGROUND_H

#define win_backgroundTilesLen 1664
extern const unsigned short win_backgroundTiles[832];

#define win_backgroundMapLen 2048
extern const unsigned short win_backgroundMap[1024];

#define win_backgroundPalLen 512
extern const unsigned short win_backgroundPal[256];

#endif // GRIT_WIN_BACKGROUND_H

//}}BLOCK(win_background)
