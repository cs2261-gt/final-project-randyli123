
//{{BLOCK(start_background)

//======================================================================
//
//	start_background, 256x256@4, 
//	+ palette 256 entries, not compressed
//	+ 2 tiles (t|f|p reduced) not compressed
//	+ regular map (in SBBs), not compressed, 32x32 
//	Total size: 512 + 64 + 2048 = 2624
//
//	Time-stamp: 2020-03-24, 15:36:45
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_START_BACKGROUND_H
#define GRIT_START_BACKGROUND_H

#define start_backgroundTilesLen 64
extern const unsigned short start_backgroundTiles[32];

#define start_backgroundMapLen 2048
extern const unsigned short start_backgroundMap[1024];

#define start_backgroundPalLen 512
extern const unsigned short start_backgroundPal[256];

#endif // GRIT_START_BACKGROUND_H

//}}BLOCK(start_background)
