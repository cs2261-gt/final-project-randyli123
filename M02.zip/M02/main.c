#include "myLib.h"
#include "game.h"
#include "spritesheet.h"
#include "house.h"

#include "start_background.h"
#include "pause_background.h"
#include "win_background.h"
#include "lose_background.h"


// Prototypes
// State Prototypes
void goToStart();
void start();
void goToGame();
void game();
void goToPause();
void pause();
void goToWin();
void win();
void goToLose();
void lose();

// States
enum {START, GAME, PAUSE, WIN, LOSE};
int state;

// Button Variables
unsigned short buttons;
unsigned short oldButtons;

int main() {

    initialize(); 

    while(1) {

        // Update button variables
        oldButtons = buttons;
        buttons = BUTTONS;

        // State Machine
        switch(state) {

            case START:
                start();
                break;
            case GAME:
                game();
                break;
            case PAUSE:
                pause();
                break;
            case WIN:
                win();
                break;
            case LOSE:
                lose();
                break;
        }

    }
}
// Sets up GBA
void initialize() {

    // Set up the display
    REG_DISPCTL = MODE0 | BG0_ENABLE | SPRITE_ENABLE;
    REG_BG0CNT = BG_CHARBLOCK(0) | BG_SCREENBLOCK(31) | BG_SIZE_SMALL;


    // Set up the first state
    goToStart();
}

// Sets up the game state
void goToGame() {

    // Make sure changes do not appear onscreen
    waitForVBlank();

    // Set up the house background
    DMANow(3, housePal, PALETTE, 256);
    DMANow(3, houseTiles, &CHARBLOCK[0], houseTilesLen / 2);
    DMANow(3, houseMap, &SCREENBLOCK[31], houseMapLen / 2);
    
    REG_BG0VOFF = vOff;
    REG_BG0HOFF = hOff;

    // Set up the sprites
    DMANow(3, spritesheetTiles, &CHARBLOCK[4], spritesheetTilesLen / 2);
    DMANow(3, spritesheetPal, SPRITEPALETTE, spritesheetPalLen / 2);
    hideSprites();
    DMANow(3, shadowOAM, OAM, 128 * 4);

    state = GAME;
}

// Runs every frame of the game state
void game() {

    updateGame();
    drawGame();
    // State transitions
    if (BUTTON_PRESSED(BUTTON_START))
        goToPause();
    else if (BUTTON_PRESSED(BUTTON_A))
        goToWin();
    else if (BUTTON_PRESSED(BUTTON_B))
        goToLose();
}
// Sets up the start state
void goToStart() {
// Load the background's palette and tiles into a desired space in memory
    DMANow(3, start_backgroundPal, PALETTE, 256);
    DMANow(3, start_backgroundTiles, &CHARBLOCK[0], start_backgroundTilesLen / 2);
    DMANow(3, start_backgroundMap, &SCREENBLOCK[28], 1024); // don't need to multiply 1024 * 4 because that is not the size of the map
    hideSprites();
    waitForVBlank();
    DMANow(3, shadowOAM, OAM, 512);
    state = START;
}

// Runs every frame of the start state
void start() {
    waitForVBlank();
    if (BUTTON_PRESSED(BUTTON_START)){
        initGame();
        goToGame();
    }
}


// Sets up the pause state
void goToPause() {
// Load the background's palette and tiles into a desired space in memory
    DMANow(3, pause_backgroundPal, PALETTE, 256);
    DMANow(3, pause_backgroundTiles, &CHARBLOCK[0], pause_backgroundTilesLen / 2);
    DMANow(3, pause_backgroundMap, &SCREENBLOCK[28], 1024); // don't need to multiply 1024 * 4 because that is not the size of the map
    hideSprites();
    waitForVBlank();
    DMANow(3, shadowOAM, OAM, 512);
    state = PAUSE;
}

// Runs every frame of the pause state
void pause() {
    waitForVBlank();
  // State transitions
    if (BUTTON_PRESSED(BUTTON_START))
        goToGame();
    else if (BUTTON_PRESSED(BUTTON_SELECT))
        goToStart();
}

// Sets up the win state
void goToWin() {
    DMANow(3, win_backgroundPal, PALETTE, 256);
    DMANow(3, win_backgroundTiles, &CHARBLOCK[0], win_backgroundTilesLen / 2);
    DMANow(3, win_backgroundMap, &SCREENBLOCK[28], 1024); // don't need to multiply 1024 * 4 because that is not the size of the map
    hideSprites();
    waitForVBlank();
    DMANow(3, shadowOAM, OAM, 512);
    state = WIN;
}

// Runs every frame of the win state
void win() {
  // Lock the framerate to 60 fps
    waitForVBlank();
    // State transitions
    if (BUTTON_PRESSED(BUTTON_START))
        goToStart();
}

// Sets up the lose state
void goToLose() {
// Load the background's palette and tiles into a desired space in memory
    DMANow(3, lose_backgroundPal, PALETTE, 256);
    DMANow(3, lose_backgroundTiles, &CHARBLOCK[0], lose_backgroundTilesLen / 2);
    DMANow(3, lose_backgroundMap, &SCREENBLOCK[28], 1024);
    hideSprites();
    waitForVBlank();
    DMANow(3, shadowOAM, OAM, 512);
    state = LOSE;
}

// Runs every frame of the lose state
void lose() {
    waitForVBlank();
    if (BUTTON_PRESSED(BUTTON_START)){
        goToStart();
    }
}