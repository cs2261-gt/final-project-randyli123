#include "myLib.h"
#include "game.h"
#include "collisionmap.h"
// TODO 2.1: Include the collision map

// Variables
int hOff;
int vOff;
OBJ_ATTR shadowOAM[128];
ANISPRITE pikachu;

// Pikachu animation states for aniState
enum {PIKAFRONT, PIKABACK, PIKARIGHT, PIKALEFT, PIKAIDLE};

// Initialize the game
void initGame() {

	// Place screen on map
    vOff = 96;
    hOff = 9;
    initPlayer();
}

// Updates the game each frame
void updateGame() {

	updatePlayer();
}

// Draws the game each frame
void drawGame() {

    drawPlayer();

    waitForVBlank();
    DMANow(3, shadowOAM, OAM, 128 * 4);

    REG_BG0HOFF = hOff;
    REG_BG0VOFF = vOff;
}

// Initialize the player
void initPlayer() {

    pikachu.width = 16;
    pikachu.height = 16;
    pikachu.rdel = 1;
    pikachu.cdel = 1;

    // Place in the middle of the screen in the world location chosen earlier
    pikachu.worldRow = SCREENHEIGHT / 2 - pikachu.width / 2 + vOff;
    pikachu.worldCol = SCREENWIDTH / 2 - pikachu.height / 2 + hOff;
    pikachu.aniCounter = 0;
    pikachu.curFrame = 0;
    pikachu.numFrames = 3;
    pikachu.aniState = PIKAFRONT;
}

// Handle every-frame actions of the player
void updatePlayer() {

    // TODO 1.0: Update to include complex camera movement
    // TODO 2.2: Update to include collision map
    if(BUTTON_HELD(BUTTON_UP)) {
        if (pikachu.worldRow > 0 // we don't care about cdel in veritcal movement
        && (collisionmapBitmap[OFFSET(pikachu.worldCol, pikachu.worldRow - pikachu.rdel, MAPWIDTH)]) //top left
        && (collisionmapBitmap[OFFSET(pikachu.worldCol + pikachu.width - 1, pikachu.worldRow - pikachu.rdel, MAPWIDTH)])){ //top right
            // Update pikachu's world position if the above is true
            while (collisionmapBitmap[OFFSET(pikachu.worldCol, pikachu.worldRow - pikachu.rdel, MAPWIDTH)] == 0x7C00 || //top left
            collisionmapBitmap[OFFSET(pikachu.worldCol + pikachu.width - 1, pikachu.worldRow - pikachu.rdel, MAPWIDTH)] == 0x7C00) {//top right)
                pikachu.worldRow  -= pikachu.rdel;
                if (vOff>0 && (pikachu.worldRow - vOff) < SCREENHEIGHT/2) {
                vOff--;
                }
            }
            
            pikachu.worldRow  -= pikachu.rdel;

            if (vOff>0 && (pikachu.worldRow - vOff) < SCREENHEIGHT/2) /*Delete that 1, then:
                for TODO 1.0, make sure the background offset doesn't show past the edge,
                and only update the offset variables if pikachu is in the right spot*/ {
                // Update background offset variable if the above is true
                vOff--;
            }
        }
    }
    if(BUTTON_HELD(BUTTON_DOWN)) {
        if (pikachu.worldRow + pikachu.height < 256 // we don't care about cdel in vertical movement
        && (collisionmapBitmap[OFFSET(pikachu.worldCol, pikachu.worldRow + pikachu.rdel + pikachu.height - 1, MAPWIDTH)]) //bottom left
        && (collisionmapBitmap[OFFSET(pikachu.worldCol + pikachu.width -1, pikachu.worldRow - pikachu.rdel + pikachu.height + 1, MAPWIDTH)])){ //bottom right
                
            // ICE 
             while (collisionmapBitmap[OFFSET(pikachu.worldCol, pikachu.worldRow + pikachu.rdel + pikachu.height - 1, MAPWIDTH)] == 0x7C00 || //top left
                collisionmapBitmap[OFFSET(pikachu.worldCol + pikachu.width -1, pikachu.worldRow - pikachu.rdel + pikachu.height + 1, MAPWIDTH)] == 0x7C00) {//top right
                pikachu.worldRow  += pikachu.rdel;
                if (vOff < MAPHEIGHT - SCREENHEIGHT && ((pikachu.worldRow - vOff) > SCREENHEIGHT/2)) { 
                vOff++;
                }
            }
            pikachu.worldRow  += pikachu.rdel;
                

            if (vOff < MAPHEIGHT - SCREENHEIGHT && ((pikachu.worldRow - vOff) > SCREENHEIGHT/2)) {
                // Update background offset variable if the above is true
                vOff++;
            }
        }
    }
    if(BUTTON_HELD(BUTTON_LEFT)) {
        if (pikachu.worldCol > 0 // need to proactively move, so decrement the worldcol by the cdel and see if were colliding
        && (collisionmapBitmap[OFFSET(pikachu.worldCol - pikachu.cdel, pikachu.worldRow , MAPWIDTH)]) //top left we don't care about rdel with horizontal movement
        && (collisionmapBitmap[OFFSET(pikachu.worldCol - pikachu.cdel, pikachu.worldRow + pikachu.height - 1, MAPWIDTH)]) ){ //bottom left
            // ICE 
             while (collisionmapBitmap[OFFSET(pikachu.worldCol - pikachu.cdel, pikachu.worldRow , MAPWIDTH)] == 0x7C00 || //top left
                collisionmapBitmap[OFFSET(pikachu.worldCol - pikachu.cdel, pikachu.worldRow + pikachu.height - 1, MAPWIDTH)] == 0x7C00) {//top right
                pikachu.worldCol  -= pikachu.cdel;
                if (hOff>0 && (pikachu.worldCol - hOff) < SCREENWIDTH/2) { 
                hOff--;
                }
            }
            // Update pikachu's world position if the above is true
            pikachu.worldCol  -= pikachu.cdel;


            if (hOff>0 && (pikachu.worldCol - hOff) < SCREENWIDTH/2) {
                // Update background offset variable if the above is true
                hOff--;
            }
        }
    }
    if(BUTTON_HELD(BUTTON_RIGHT)) {
        if (pikachu.worldCol + pikachu.width < 256   // again, we need to be proactive and add cdel to our check
        && (collisionmapBitmap[OFFSET(pikachu.worldCol + pikachu.cdel + pikachu.width - 1, pikachu.worldRow , MAPWIDTH)]) //top right
        && (collisionmapBitmap[OFFSET(pikachu.worldCol + pikachu.cdel + pikachu.width - 1, pikachu.worldRow  + pikachu.height - 1, MAPWIDTH)]) ){ //bottom right
            // ICE 
             while (collisionmapBitmap[OFFSET(pikachu.worldCol + pikachu.cdel + pikachu.width - 1, pikachu.worldRow , MAPWIDTH)] == 0x7C00 || //top left
                collisionmapBitmap[OFFSET(pikachu.worldCol + pikachu.cdel + pikachu.width - 1, pikachu.worldRow  + pikachu.height - 1, MAPWIDTH)] == 0x7C00) {//top right
                pikachu.worldCol  += pikachu.cdel;
                if (hOff>0 && (pikachu.worldCol - hOff) < SCREENWIDTH/2) { 
                hOff++;
                }
            }
            // Update pikachu's world position if the above is true
            pikachu.worldCol  += pikachu.cdel;


            if (hOff < MAPWIDTH - SCREENWIDTH && ((pikachu.worldCol - hOff) > SCREENWIDTH/2)) {
                // Update background offset variable if the above is true
                hOff++;
            }
        }
    }

    // TODO 1.0: Update screen row and screen col
    
    pikachu.screenRow = pikachu.worldRow -  vOff;
    pikachu.screenCol = pikachu.worldCol - hOff;
    animatePlayer();
}

// Handle player animation states
void animatePlayer() {

    // Set previous state to current state
    pikachu.prevAniState = pikachu.aniState;
    pikachu.aniState = PIKAIDLE;

    // Change the animation frame every 20 frames of gameplay
    if(pikachu.aniCounter % 20 == 0) {
        pikachu.curFrame = (pikachu.curFrame + 1) % pikachu.numFrames;
    }

    // Control movement and change animation state
    if(BUTTON_HELD(BUTTON_UP))
        pikachu.aniState = PIKABACK;
    if(BUTTON_HELD(BUTTON_DOWN))
        pikachu.aniState = PIKAFRONT;
    if(BUTTON_HELD(BUTTON_LEFT))
        pikachu.aniState = PIKALEFT;
    if(BUTTON_HELD(BUTTON_RIGHT))
        pikachu.aniState = PIKARIGHT;

    // If the pikachu aniState is idle, frame is pikachu standing
    if (pikachu.aniState == PIKAIDLE) {
        pikachu.curFrame = 0;
        pikachu.aniCounter = 0;
        pikachu.aniState = pikachu.prevAniState;
    } else {
        pikachu.aniCounter++;
    }
}

// Draw the player
void drawPlayer() {

    if (pikachu.hide) {
        shadowOAM[0].attr0 |= ATTR0_HIDE;
    } else {
        shadowOAM[0].attr0 = (ROWMASK & pikachu.screenRow) | ATTR0_SQUARE;
        shadowOAM[0].attr1 = (COLMASK & pikachu.screenCol) | ATTR1_SMALL;
        shadowOAM[0].attr2 = ATTR2_PALROW(0) | ATTR2_TILEID(pikachu.aniState * 2, pikachu.curFrame * 2);
    }
}