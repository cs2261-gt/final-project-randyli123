
//{{BLOCK(lose_background)

//======================================================================
//
//	lose_background, 256x256@4, 
//	+ palette 256 entries, not compressed
//	+ 1 tiles (t|f|p reduced) not compressed
//	+ regular map (in SBBs), not compressed, 32x32 
//	Total size: 512 + 32 + 2048 = 2592
//
//	Time-stamp: 2020-03-24, 15:37:44
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_LOSE_BACKGROUND_H
#define GRIT_LOSE_BACKGROUND_H

#define lose_backgroundTilesLen 32
extern const unsigned short lose_backgroundTiles[16];

#define lose_backgroundMapLen 2048
extern const unsigned short lose_backgroundMap[1024];

#define lose_backgroundPalLen 512
extern const unsigned short lose_backgroundPal[256];

#endif // GRIT_LOSE_BACKGROUND_H

//}}BLOCK(lose_background)
