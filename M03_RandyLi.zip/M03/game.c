#include "myLib.h"
#include "game.h"
#include "collisionmap.h"
#include "collisionmap2.h"


// Variables
int hOff;
int vOff;
OBJ_ATTR shadowOAM[128];
ANISPRITE pikachu;
ANISPRITE torch;
int afterIce;
int isSliding;
int torchTimer;
int pos;


// time ice movement!
int iceTimer;

// used to determine how pikachu should move across the ice
int direction;
enum {DOWN, UP, RIGHT, LEFT};

// Pikachu animation states for aniState
enum {PIKAFRONT, PIKABACK, PIKARIGHT, PIKALEFT, PIKAIDLE};

// Initialize the game
void initGame() {

	// Place screen on map
    vOff = 96;
    hOff = 9;
    iceTimer = 0;
    direction = DOWN; // pikachu initially facing forward
    isSliding = 0;
    initPlayer();
    initTorch();
}
// Initialize the game
void initGame2() {

	// Place screen on map
    vOff = 96;
    hOff = 9;
    iceTimer = 0;
    direction = DOWN; // pikachu initially facing forward
    isSliding = 0;
    initPlayer2();
    initTorch2();
}

// Updates the game each frame
void updateGame() {
	updatePlayer();
    updateTorch();
}

// Updates the game second level each frame
void updateGame2() {
	updatePlayer2();
    updateTorch();
}

// Draws the game each frame
void drawGame() {

    drawPlayer();
    drawTorch();

    waitForVBlank();
    DMANow(3, shadowOAM, OAM, 128 * 4);

    REG_BG0HOFF = hOff;
    REG_BG0VOFF = vOff;
}

// Initialize the player
void initPlayer() {

    pikachu.width = 16;
    pikachu.height = 16;
    pikachu.rdel = 1;
    pikachu.cdel = 1;

    // Place in the middle of the screen in the world location chosen earlier
    pikachu.worldRow = 230; //SCREENHEIGHT / 2 - pikachu.width / 2 + vOff;
    pikachu.worldCol = 120; //SCREENWIDTH / 2 - pikachu.height / 2 + hOff;
    pikachu.aniCounter = 0;
    pikachu.curFrame = 0;
    pikachu.numFrames = 3;
    pikachu.aniState = PIKAFRONT;
}

// Initialize the player
void initPlayer2() {

    pikachu.width = 16;
    pikachu.height = 16;
    pikachu.rdel = 1;
    pikachu.cdel = 1;

    // Place in the middle of the screen in the world location chosen earlier
    pikachu.worldRow = 240; //SCREENHEIGHT / 2 - pikachu.width / 2 + vOff;
    pikachu.worldCol = 10; //SCREENWIDTH / 2 - pikachu.height / 2 + hOff;
    pikachu.aniCounter = 0;
    pikachu.curFrame = 0;
    pikachu.numFrames = 3;
    pikachu.aniState = PIKAFRONT;
}

// Initialize the torch
void initTorch() {

    torch.width = 16;
    torch.height = 16;

    // Place in the middle of the screen in the world location chosen earlier
    torch.worldRow = 38; //SCREENHEIGHT / 2 - pikachu.width / 2 + vOff;
    torch.worldCol = 190; //SCREENWIDTH / 2 - pikachu.height / 2 + hOff;
    torch.aniCounter = 0;
    torch.curFrame = 0;
    torch.numFrames = 3;
}
// Initialize the torch
void initTorch2() {

    torch.width = 16;
    torch.height = 16;

    // Place in the middle of the screen in the world location chosen earlier
    torch.worldRow = 150; //SCREENHEIGHT / 2 - pikachu.width / 2 + vOff;
    torch.worldCol = 240; //SCREENWIDTH / 2 - pikachu.height / 2 + hOff;
    torch.aniCounter = 0;
    torch.curFrame = 0;
    torch.numFrames = 3;
}

// this DOESN'T happen based on user input - pikachu should just move if colliding with blue on collisionmap
void updatePlayerOnIce() {
    
    //UP
        if (direction == UP && pikachu.worldRow > 0
        && (collisionmapBitmap[OFFSET(pikachu.worldCol, pikachu.worldRow - pikachu.rdel, MAPWIDTH)] == BLUE) //top left
        && (collisionmapBitmap[OFFSET(pikachu.worldCol + pikachu.width - 1, pikachu.worldRow - pikachu.rdel, MAPWIDTH)] == BLUE)){ //top right
            isSliding = 1;
            pikachu.worldRow  -= pikachu.rdel;
            
            if (vOff > 0 && (pikachu.worldRow - vOff) < SCREENHEIGHT/2) {
                vOff--;
            } 
        }

//back of UP
        else if (direction == UP && pikachu.worldRow > 0
        && (collisionmapBitmap[OFFSET(pikachu.worldCol, pikachu.worldRow + pikachu.rdel + pikachu.height - 1, MAPWIDTH)] == BLUE) //bottom left
        && (collisionmapBitmap[OFFSET(pikachu.worldCol + pikachu.width -1, pikachu.worldRow - pikachu.rdel + pikachu.height + 1, MAPWIDTH)] == BLUE)){ //bottom right
            
            if (collisionmapBitmap[OFFSET(pikachu.worldCol, pikachu.worldRow - pikachu.rdel, MAPWIDTH)] == WHITE //top left
            && collisionmapBitmap[OFFSET(pikachu.worldCol + pikachu.width - 1, pikachu.worldRow - pikachu.rdel, MAPWIDTH)] == WHITE){ //top right
            
                pikachu.worldRow  -= pikachu.rdel;
                isSliding = 0;
                if (vOff > 0 && (pikachu.worldRow - vOff) < SCREENHEIGHT/2) {
                    vOff--;
                 }
            }
        }
    
    //DOWN 
        else if (direction == DOWN && pikachu.worldRow + pikachu.height < 256 // we don't care about cdel in vertical movement
        && (collisionmapBitmap[OFFSET(pikachu.worldCol, pikachu.worldRow + pikachu.rdel + pikachu.height - 1, MAPWIDTH)] == BLUE) //bottom left
        && (collisionmapBitmap[OFFSET(pikachu.worldCol + pikachu.width -1, pikachu.worldRow - pikachu.rdel + pikachu.height + 1, MAPWIDTH)] == BLUE)){ //bottom right
            isSliding = 1;    
            pikachu.worldRow  += pikachu.rdel;
                
            if (vOff < MAPHEIGHT - SCREENHEIGHT && ((pikachu.worldRow - vOff) > SCREENHEIGHT/2)) {
                vOff++;
            }

        }
        //back of DOWN
        else if (direction == DOWN && pikachu.worldRow + pikachu.height < 256 // we don't care about cdel in vertical movement
        && (collisionmapBitmap[OFFSET(pikachu.worldCol, pikachu.worldRow - pikachu.rdel, MAPWIDTH)] == BLUE) //top left
        && (collisionmapBitmap[OFFSET(pikachu.worldCol + pikachu.width - 1, pikachu.worldRow - pikachu.rdel, MAPWIDTH)] == BLUE)){ //top right
   
            if (collisionmapBitmap[OFFSET(pikachu.worldCol, pikachu.worldRow + pikachu.rdel + pikachu.height - 1, MAPWIDTH)] == WHITE //bottom left
            && collisionmapBitmap[OFFSET(pikachu.worldCol + pikachu.width -1, pikachu.worldRow - pikachu.rdel + pikachu.height + 1, MAPWIDTH)] == WHITE){ //bottom right
            
                pikachu.worldRow  += pikachu.rdel;
                isSliding = 0;
                if (vOff < MAPHEIGHT - SCREENHEIGHT && ((pikachu.worldRow - vOff) > SCREENHEIGHT/2)) {
                    vOff++;
                }
            }
         }

    //LEFT
        else if (direction == LEFT && pikachu.worldCol > 0
        && (collisionmapBitmap[OFFSET(pikachu.worldCol - pikachu.cdel, pikachu.worldRow , MAPWIDTH)] == BLUE) //top left
        && (collisionmapBitmap[OFFSET(pikachu.worldCol - pikachu.cdel, pikachu.worldRow + pikachu.height - 1, MAPWIDTH)] == BLUE) ){ //bottom left
            isSliding = 1;
            pikachu.worldCol  -= pikachu.cdel;

            if (hOff>0 && (pikachu.worldCol - hOff) < SCREENWIDTH/2) {
                hOff--;
            }
        }
        //back of Left
        else if (direction == LEFT && pikachu.worldCol > 0
        && (collisionmapBitmap[OFFSET(pikachu.worldCol + pikachu.cdel + pikachu.width - 1, pikachu.worldRow , MAPWIDTH)] == BLUE) //top right
        && (collisionmapBitmap[OFFSET(pikachu.worldCol + pikachu.cdel + pikachu.width - 1, pikachu.worldRow  + pikachu.height - 1, MAPWIDTH)] == BLUE)){ //bottom right

            if (collisionmapBitmap[OFFSET(pikachu.worldCol - pikachu.cdel, pikachu.worldRow , MAPWIDTH)] == WHITE //top left
            && collisionmapBitmap[OFFSET(pikachu.worldCol - pikachu.cdel, pikachu.worldRow + pikachu.height - 1, MAPWIDTH)] == WHITE){ //bottom left
                
                pikachu.worldCol  -= pikachu.cdel;
                isSliding = 0;
                if (hOff>0 && (pikachu.worldCol - hOff) < SCREENWIDTH/2) {
                    hOff--;
                }
            }
        }
    //RIGHT
        else if (direction == RIGHT && pikachu.worldCol + pikachu.width < 256   // again, we need to be proactive and add cdel to our check
        && (collisionmapBitmap[OFFSET(pikachu.worldCol + pikachu.cdel + pikachu.width - 1, pikachu.worldRow , MAPWIDTH)] == BLUE) //top right
        && (collisionmapBitmap[OFFSET(pikachu.worldCol + pikachu.cdel + pikachu.width - 1, pikachu.worldRow  + pikachu.height - 1, MAPWIDTH)] == BLUE)){ //bottom right
            isSliding = 1;
            pikachu.worldCol  += pikachu.cdel;

            if (hOff < MAPWIDTH - SCREENWIDTH && ((pikachu.worldCol - hOff) > SCREENWIDTH/2)) {
                hOff++;
            }
        }
        //back of Right
        else if (direction == RIGHT && pikachu.worldCol + pikachu.width < 256   // again, we need to be proactive and add cdel to our check
        && (collisionmapBitmap[OFFSET(pikachu.worldCol - pikachu.cdel, pikachu.worldRow , MAPWIDTH)] == BLUE) //top left
        && (collisionmapBitmap[OFFSET(pikachu.worldCol - pikachu.cdel, pikachu.worldRow + pikachu.height - 1, MAPWIDTH)] == BLUE)){ //bottom left

            if (collisionmapBitmap[OFFSET(pikachu.worldCol + pikachu.cdel + pikachu.width - 1, pikachu.worldRow , MAPWIDTH)] == WHITE //top right
            && collisionmapBitmap[OFFSET(pikachu.worldCol + pikachu.cdel + pikachu.width - 1, pikachu.worldRow  + pikachu.height - 1, MAPWIDTH)] == WHITE){ //bottom right

                pikachu.worldCol  += pikachu.cdel;
                isSliding = 0;
                if (hOff < MAPWIDTH - SCREENWIDTH && ((pikachu.worldCol - hOff) > SCREENWIDTH/2)) {
                     hOff++;
                }
            }
        }
        
        //LEFT WALL
        if (direction == LEFT
            && collisionmapBitmap[OFFSET(pikachu.worldCol - pikachu.cdel, pikachu.worldRow , MAPWIDTH)] == BLACK //top left
            && collisionmapBitmap[OFFSET(pikachu.worldCol - pikachu.cdel, pikachu.worldRow + pikachu.height - 1, MAPWIDTH)] == BLACK){ //bottom left
                isSliding = 0;
            } 
        //RIGHT WALL
        else if (direction ==  RIGHT
            && collisionmapBitmap[OFFSET(pikachu.worldCol + pikachu.cdel + pikachu.width - 1, pikachu.worldRow , MAPWIDTH)] == BLACK //top left
            && collisionmapBitmap[OFFSET(pikachu.worldCol + pikachu.cdel + pikachu.width - 1, pikachu.worldRow  + pikachu.height - 1, MAPWIDTH)] == BLACK) { 
                isSliding = 0;
            }
        //TOP WALL
        else if (direction ==  UP
            && collisionmapBitmap[OFFSET(pikachu.worldCol, pikachu.worldRow - pikachu.rdel, MAPWIDTH)] == BLACK //top left
            && collisionmapBitmap[OFFSET(pikachu.worldCol + pikachu.width - 1, pikachu.worldRow - pikachu.rdel, MAPWIDTH)] == BLACK) { 
                isSliding = 0;
            }
        //DOWN WALL
        else if (direction ==  DOWN
            && collisionmapBitmap[OFFSET(pikachu.worldCol, pikachu.worldRow + pikachu.rdel + pikachu.height - 1, MAPWIDTH)] == BLACK //bottom left
            && collisionmapBitmap[OFFSET(pikachu.worldCol + pikachu.width -1, pikachu.worldRow - pikachu.rdel + pikachu.height + 1, MAPWIDTH)] == BLACK) { 
                isSliding = 0;
            }

    }

// Handle every-frame actions of the player
void updatePlayer2() {

    updatePlayerOnIce2();

    // all of user input based movement should occur on white spots on our collision map!
    if(BUTTON_HELD(BUTTON_UP) && isSliding == 0) {
        direction = UP;

        if (pikachu.worldRow > 0 // we don't care about cdel in veritcal movement
        && (collisionmap2Bitmap[OFFSET(pikachu.worldCol, pikachu.worldRow - pikachu.rdel, MAPWIDTH)] == WHITE) //top left
        && (collisionmap2Bitmap[OFFSET(pikachu.worldCol + pikachu.width - 1, pikachu.worldRow - pikachu.rdel, MAPWIDTH)] == WHITE)){ //top right

            pikachu.worldRow  -= pikachu.rdel;

            if (vOff>0 && (pikachu.worldRow - vOff) < SCREENHEIGHT/2) {
                vOff--;
            }
        }
    }
    else if(BUTTON_HELD(BUTTON_DOWN) && isSliding == 0) {
        direction = DOWN;

        if (pikachu.worldRow + pikachu.height < 256 // we don't care about cdel in vertical movement
        && (collisionmap2Bitmap[OFFSET(pikachu.worldCol, pikachu.worldRow + pikachu.rdel + pikachu.height - 1, MAPWIDTH)] == WHITE) //bottom left
        && (collisionmap2Bitmap[OFFSET(pikachu.worldCol + pikachu.width -1, pikachu.worldRow - pikachu.rdel + pikachu.height + 1, MAPWIDTH)] == WHITE)){ //bottom right
                
            pikachu.worldRow  += pikachu.rdel;

            if (vOff < MAPHEIGHT - SCREENHEIGHT && ((pikachu.worldRow - vOff) > SCREENHEIGHT/2)) {
                // Update background offset variable if the above is true
                vOff++;
            }
        }
    }
    else if(BUTTON_HELD(BUTTON_LEFT) && isSliding == 0) {
        direction = LEFT;

        if (pikachu.worldCol > 0 // need to proactively move, so decrement the worldcol by the cdel and see if were colliding
        && (collisionmap2Bitmap[OFFSET(pikachu.worldCol - pikachu.cdel, pikachu.worldRow , MAPWIDTH)] == WHITE) //top left we don't care about rdel with horizontal movement
        && (collisionmap2Bitmap[OFFSET(pikachu.worldCol - pikachu.cdel, pikachu.worldRow + pikachu.height - 1, MAPWIDTH)] == WHITE)){ //bottom left
   
            // Update pikachu's world position if the above is true
            pikachu.worldCol  -= pikachu.cdel;
            won = 1;


            if (hOff>0 && (pikachu.worldCol - hOff) < SCREENWIDTH/2) {
                // Update background offset variable if the above is true
                hOff--;
            }
        }
    }
    else if(BUTTON_HELD(BUTTON_RIGHT) && isSliding == 0) {
        direction = RIGHT;

        if (pikachu.worldCol + pikachu.width < 256   // again, we need to be proactive and add cdel to our check
        && (collisionmap2Bitmap[OFFSET(pikachu.worldCol + pikachu.cdel + pikachu.width - 1, pikachu.worldRow , MAPWIDTH)] == WHITE) //top right
        && (collisionmap2Bitmap[OFFSET(pikachu.worldCol + pikachu.cdel + pikachu.width - 1, pikachu.worldRow  + pikachu.height - 1, MAPWIDTH)] == WHITE)){ //bottom right

            // Update pikachu's world position if the above is true
            pikachu.worldCol  += pikachu.cdel;

            if (hOff < MAPWIDTH - SCREENWIDTH && ((pikachu.worldCol - hOff) > SCREENWIDTH/2)) {
                // Update background offset variable if the above is true
                hOff++;
            }
        }
    }

    //Update screen row and screen col
    
    pikachu.screenRow = pikachu.worldRow -  vOff;
    pikachu.screenCol = pikachu.worldCol - hOff;
    torch.screenRow = torch.worldRow -  vOff;
    torch.screenCol = torch.worldCol - hOff;
    torchTimer++;
    animatePlayer();
    winCheck();
}

void updatePlayerOnIce2() {
    
    //UP
        if (direction == UP && pikachu.worldRow > 0
        && (collisionmap2Bitmap[OFFSET(pikachu.worldCol, pikachu.worldRow - pikachu.rdel, MAPWIDTH)] == BLUE) //top left
        && (collisionmap2Bitmap[OFFSET(pikachu.worldCol + pikachu.width - 1, pikachu.worldRow - pikachu.rdel, MAPWIDTH)] == BLUE)){ //top right
            isSliding = 1;
            pikachu.worldRow  -= pikachu.rdel;
            
            if (vOff > 0 && (pikachu.worldRow - vOff) < SCREENHEIGHT/2) {
                vOff--;
            } 
        }

//back of UP
        else if (direction == UP && pikachu.worldRow > 0
        && (collisionmap2Bitmap[OFFSET(pikachu.worldCol, pikachu.worldRow + pikachu.rdel + pikachu.height - 1, MAPWIDTH)] == BLUE) //bottom left
        && (collisionmap2Bitmap[OFFSET(pikachu.worldCol + pikachu.width -1, pikachu.worldRow - pikachu.rdel + pikachu.height + 1, MAPWIDTH)] == BLUE)){ //bottom right
            
            if (collisionmap2Bitmap[OFFSET(pikachu.worldCol, pikachu.worldRow - pikachu.rdel, MAPWIDTH)] == WHITE //top left
            && collisionmap2Bitmap[OFFSET(pikachu.worldCol + pikachu.width - 1, pikachu.worldRow - pikachu.rdel, MAPWIDTH)] == WHITE){ //top right
            
                pikachu.worldRow  -= pikachu.rdel;
                isSliding = 0;
                if (vOff > 0 && (pikachu.worldRow - vOff) < SCREENHEIGHT/2) {
                    vOff--;
                 }
            }
        }
    
    //DOWN 
        else if (direction == DOWN && pikachu.worldRow + pikachu.height < 256 // we don't care about cdel in vertical movement
        && (collisionmap2Bitmap[OFFSET(pikachu.worldCol, pikachu.worldRow + pikachu.rdel + pikachu.height - 1, MAPWIDTH)] == BLUE) //bottom left
        && (collisionmap2Bitmap[OFFSET(pikachu.worldCol + pikachu.width -1, pikachu.worldRow - pikachu.rdel + pikachu.height + 1, MAPWIDTH)] == BLUE)){ //bottom right
            isSliding = 1;    
            pikachu.worldRow  += pikachu.rdel;
                
            if (vOff < MAPHEIGHT - SCREENHEIGHT && ((pikachu.worldRow - vOff) > SCREENHEIGHT/2)) {
                vOff++;
            }

        }
        //back of DOWN
        else if (direction == DOWN && pikachu.worldRow + pikachu.height < 256 // we don't care about cdel in vertical movement
        && (collisionmap2Bitmap[OFFSET(pikachu.worldCol, pikachu.worldRow - pikachu.rdel, MAPWIDTH)] == BLUE) //top left
        && (collisionmap2Bitmap[OFFSET(pikachu.worldCol + pikachu.width - 1, pikachu.worldRow - pikachu.rdel, MAPWIDTH)] == BLUE)){ //top right
   
            if (collisionmap2Bitmap[OFFSET(pikachu.worldCol, pikachu.worldRow + pikachu.rdel + pikachu.height - 1, MAPWIDTH)] == WHITE //bottom left
            && collisionmap2Bitmap[OFFSET(pikachu.worldCol + pikachu.width -1, pikachu.worldRow - pikachu.rdel + pikachu.height + 1, MAPWIDTH)] == WHITE){ //bottom right
            
                pikachu.worldRow  += pikachu.rdel;
                isSliding = 0;
                if (vOff < MAPHEIGHT - SCREENHEIGHT && ((pikachu.worldRow - vOff) > SCREENHEIGHT/2)) {
                    vOff++;
                }
            }
         }

    //LEFT
        else if (direction == LEFT && pikachu.worldCol > 0
        && (collisionmap2Bitmap[OFFSET(pikachu.worldCol - pikachu.cdel, pikachu.worldRow , MAPWIDTH)] == BLUE) //top left
        && (collisionmap2Bitmap[OFFSET(pikachu.worldCol - pikachu.cdel, pikachu.worldRow + pikachu.height - 1, MAPWIDTH)] == BLUE) ){ //bottom left
            isSliding = 1;
            pikachu.worldCol  -= pikachu.cdel;

            if (hOff>0 && (pikachu.worldCol - hOff) < SCREENWIDTH/2) {
                hOff--;
            }
        }
        //back of Left
        else if (direction == LEFT && pikachu.worldCol > 0
        && (collisionmap2Bitmap[OFFSET(pikachu.worldCol + pikachu.cdel + pikachu.width - 1, pikachu.worldRow , MAPWIDTH)] == BLUE) //top right
        && (collisionmap2Bitmap[OFFSET(pikachu.worldCol + pikachu.cdel + pikachu.width - 1, pikachu.worldRow  + pikachu.height - 1, MAPWIDTH)] == BLUE)){ //bottom right

            if (collisionmap2Bitmap[OFFSET(pikachu.worldCol - pikachu.cdel, pikachu.worldRow , MAPWIDTH)] == WHITE //top left
            && collisionmap2Bitmap[OFFSET(pikachu.worldCol - pikachu.cdel, pikachu.worldRow + pikachu.height - 1, MAPWIDTH)] == WHITE){ //bottom left
                
                pikachu.worldCol  -= pikachu.cdel;
                isSliding = 0;
                if (hOff>0 && (pikachu.worldCol - hOff) < SCREENWIDTH/2) {
                    hOff--;
                }
            }
        }
    //RIGHT
        else if (direction == RIGHT && pikachu.worldCol + pikachu.width < 256   // again, we need to be proactive and add cdel to our check
        && (collisionmap2Bitmap[OFFSET(pikachu.worldCol + pikachu.cdel + pikachu.width - 1, pikachu.worldRow , MAPWIDTH)] == BLUE) //top right
        && (collisionmap2Bitmap[OFFSET(pikachu.worldCol + pikachu.cdel + pikachu.width - 1, pikachu.worldRow  + pikachu.height - 1, MAPWIDTH)] == BLUE)){ //bottom right
            isSliding = 1;
            pikachu.worldCol  += pikachu.cdel;

            if (hOff < MAPWIDTH - SCREENWIDTH && ((pikachu.worldCol - hOff) > SCREENWIDTH/2)) {
                hOff++;
            }
        }
        //back of Right
        else if (direction == RIGHT && pikachu.worldCol + pikachu.width < 256   // again, we need to be proactive and add cdel to our check
        && (collisionmap2Bitmap[OFFSET(pikachu.worldCol - pikachu.cdel, pikachu.worldRow , MAPWIDTH)] == BLUE) //top left
        && (collisionmap2Bitmap[OFFSET(pikachu.worldCol - pikachu.cdel, pikachu.worldRow + pikachu.height - 1, MAPWIDTH)] == BLUE)){ //bottom left

            if (collisionmap2Bitmap[OFFSET(pikachu.worldCol + pikachu.cdel + pikachu.width - 1, pikachu.worldRow , MAPWIDTH)] == WHITE //top right
            && collisionmap2Bitmap[OFFSET(pikachu.worldCol + pikachu.cdel + pikachu.width - 1, pikachu.worldRow  + pikachu.height - 1, MAPWIDTH)] == WHITE){ //bottom right

                pikachu.worldCol  += pikachu.cdel;
                isSliding = 0;
                if (hOff < MAPWIDTH - SCREENWIDTH && ((pikachu.worldCol - hOff) > SCREENWIDTH/2)) {
                     hOff++;
                }
            }
        }
        
        //LEFT WALL
        if (direction == LEFT
            && collisionmap2Bitmap[OFFSET(pikachu.worldCol - pikachu.cdel, pikachu.worldRow , MAPWIDTH)] == BLACK //top left
            && collisionmap2Bitmap[OFFSET(pikachu.worldCol - pikachu.cdel, pikachu.worldRow + pikachu.height - 1, MAPWIDTH)] == BLACK){ //bottom left
                isSliding = 0;
            } 
        //RIGHT WALL
        else if (direction ==  RIGHT
            && collisionmap2Bitmap[OFFSET(pikachu.worldCol + pikachu.cdel + pikachu.width - 1, pikachu.worldRow , MAPWIDTH)] == BLACK //top left
            && collisionmap2Bitmap[OFFSET(pikachu.worldCol + pikachu.cdel + pikachu.width - 1, pikachu.worldRow  + pikachu.height - 1, MAPWIDTH)] == BLACK) { 
                isSliding = 0;
            }
        //TOP WALL
        else if (direction ==  UP
            && collisionmap2Bitmap[OFFSET(pikachu.worldCol, pikachu.worldRow - pikachu.rdel, MAPWIDTH)] == BLACK //top left
            && collisionmap2Bitmap[OFFSET(pikachu.worldCol + pikachu.width - 1, pikachu.worldRow - pikachu.rdel, MAPWIDTH)] == BLACK) { 
                isSliding = 0;
            }
        //DOWN WALL
        else if (direction ==  DOWN
            && collisionmap2Bitmap[OFFSET(pikachu.worldCol, pikachu.worldRow + pikachu.rdel + pikachu.height - 1, MAPWIDTH)] == BLACK //bottom left
            && collisionmap2Bitmap[OFFSET(pikachu.worldCol + pikachu.width -1, pikachu.worldRow - pikachu.rdel + pikachu.height + 1, MAPWIDTH)] == BLACK) { 
                isSliding = 0;
            }

    }

// Handle every-frame actions of the player
void updatePlayer() {

    updatePlayerOnIce();

    // all of user input based movement should occur on white spots on our collision map!
    if(BUTTON_HELD(BUTTON_UP) && isSliding == 0) {
        direction = UP;

        if (pikachu.worldRow > 0 // we don't care about cdel in veritcal movement
        && (collisionmapBitmap[OFFSET(pikachu.worldCol, pikachu.worldRow - pikachu.rdel, MAPWIDTH)] == WHITE) //top left
        && (collisionmapBitmap[OFFSET(pikachu.worldCol + pikachu.width - 1, pikachu.worldRow - pikachu.rdel, MAPWIDTH)] == WHITE)){ //top right

            pikachu.worldRow  -= pikachu.rdel;

            if (vOff>0 && (pikachu.worldRow - vOff) < SCREENHEIGHT/2) {
                vOff--;
            }
        }
    }
    else if(BUTTON_HELD(BUTTON_DOWN) && isSliding == 0) {
        direction = DOWN;

        if (pikachu.worldRow + pikachu.height < 256 // we don't care about cdel in vertical movement
        && (collisionmapBitmap[OFFSET(pikachu.worldCol, pikachu.worldRow + pikachu.rdel + pikachu.height - 1, MAPWIDTH)] == WHITE) //bottom left
        && (collisionmapBitmap[OFFSET(pikachu.worldCol + pikachu.width -1, pikachu.worldRow - pikachu.rdel + pikachu.height + 1, MAPWIDTH)] == WHITE)){ //bottom right
                
            pikachu.worldRow  += pikachu.rdel;

            if (vOff < MAPHEIGHT - SCREENHEIGHT && ((pikachu.worldRow - vOff) > SCREENHEIGHT/2)) {
                // Update background offset variable if the above is true
                vOff++;
            }
        }
    }
    else if(BUTTON_HELD(BUTTON_LEFT) && isSliding == 0) {
        direction = LEFT;

        if (pikachu.worldCol > 0 // need to proactively move, so decrement the worldcol by the cdel and see if were colliding
        && (collisionmapBitmap[OFFSET(pikachu.worldCol - pikachu.cdel, pikachu.worldRow , MAPWIDTH)] == WHITE) //top left we don't care about rdel with horizontal movement
        && (collisionmapBitmap[OFFSET(pikachu.worldCol - pikachu.cdel, pikachu.worldRow + pikachu.height - 1, MAPWIDTH)] == WHITE)){ //bottom left
   
            // Update pikachu's world position if the above is true
            pikachu.worldCol  -= pikachu.cdel;


            if (hOff>0 && (pikachu.worldCol - hOff) < SCREENWIDTH/2) {
                // Update background offset variable if the above is true
                hOff--;
            }
        }
    }
    else if(BUTTON_HELD(BUTTON_RIGHT) && isSliding == 0) {
        direction = RIGHT;

        if (pikachu.worldCol + pikachu.width < 256   // again, we need to be proactive and add cdel to our check
        && (collisionmapBitmap[OFFSET(pikachu.worldCol + pikachu.cdel + pikachu.width - 1, pikachu.worldRow , MAPWIDTH)] == WHITE) //top right
        && (collisionmapBitmap[OFFSET(pikachu.worldCol + pikachu.cdel + pikachu.width - 1, pikachu.worldRow  + pikachu.height - 1, MAPWIDTH)] == WHITE)){ //bottom right

            // Update pikachu's world position if the above is true
            pikachu.worldCol  += pikachu.cdel;

            if (hOff < MAPWIDTH - SCREENWIDTH && ((pikachu.worldCol - hOff) > SCREENWIDTH/2)) {
                // Update background offset variable if the above is true
                hOff++;
            }
        }
    }

    //Update screen row and screen col
    
    pikachu.screenRow = pikachu.worldRow -  vOff;
    pikachu.screenCol = pikachu.worldCol - hOff;
    torch.screenRow = torch.worldRow -  vOff;
    torch.screenCol = torch.worldCol - hOff;

    torchTimer++;
    animatePlayer();
    winCheck();
}

// Handle player animation states
void animatePlayer() {

    // Set previous state to current state
    pikachu.prevAniState = pikachu.aniState;
    pikachu.aniState = PIKAIDLE;

    // Change the animation frame every 20 frames of gameplay
    if(pikachu.aniCounter % 20 == 0) {
        pikachu.curFrame = (pikachu.curFrame + 1) % pikachu.numFrames;
    }

    // Control movement and change animation state
    if(BUTTON_HELD(BUTTON_UP))
        pikachu.aniState = PIKABACK;
    if(BUTTON_HELD(BUTTON_DOWN))
        pikachu.aniState = PIKAFRONT;
    if(BUTTON_HELD(BUTTON_LEFT))
        pikachu.aniState = PIKALEFT;
    if(BUTTON_HELD(BUTTON_RIGHT))
        pikachu.aniState = PIKARIGHT;

    // If the pikachu aniState is idle, frame is pikachu standing
    if (pikachu.aniState == PIKAIDLE) {
        pikachu.curFrame = 0;
        pikachu.aniCounter = 0;
        pikachu.aniState = pikachu.prevAniState;
    } else {
        pikachu.aniCounter++;
    }
}

// Draw the player
void drawPlayer() {

    if (pikachu.hide) {
        shadowOAM[0].attr0 |= ATTR0_HIDE;
    } else {
        shadowOAM[0].attr0 = (ROWMASK & pikachu.screenRow) | ATTR0_SQUARE;
        shadowOAM[0].attr1 = (COLMASK & pikachu.screenCol) | ATTR1_SMALL;
        shadowOAM[0].attr2 = ATTR2_PALROW(0) | ATTR2_TILEID(pikachu.aniState * 2, pikachu.curFrame * 2);
    }
}

// Draw the torch
void drawTorch() {

    if (torch.hide) {
        shadowOAM[1].attr0 |= ATTR0_HIDE;
    } else {
        shadowOAM[1].attr0 = (ROWMASK & torch.screenRow) | ATTR0_SQUARE;
        shadowOAM[1].attr1 = (COLMASK & torch.screenCol) | ATTR1_SMALL;
        shadowOAM[1].attr2 = ATTR2_PALROW(0) | ATTR2_TILEID(8, pos * 2);
    }
}

void updateTorch() {

	// animation for the torch
	if (torchTimer % 10 == 0) { // only change animation frame every 10 frames
		pos = (pos + 1) % 3; // increment the frame and loop the frame if adding 1 would result in a number greater than the number of frame (3 frames total)
	}
    
	if (collision(pikachu.worldCol, pikachu.worldRow , pikachu.width, pikachu.height, torch.worldCol, torch.worldRow, torch.width, torch.height)) {
		won = 1;
	}
}

//   checks win condition
void winCheck() {
    if ((collisionmapBitmap[OFFSET(pikachu.worldCol, pikachu.worldRow - pikachu.rdel, MAPWIDTH)] == 0x001F) //top left
        || (collisionmapBitmap[OFFSET(pikachu.worldCol + pikachu.width - 1, pikachu.worldRow - pikachu.rdel, MAPWIDTH)] == 0x001F) //top right
        || (collisionmapBitmap[OFFSET(pikachu.worldCol, pikachu.worldRow + pikachu.rdel + pikachu.height - 1, MAPWIDTH)] == 0x001F) //bottom left
        || (collisionmapBitmap[OFFSET(pikachu.worldCol + pikachu.width -1, pikachu.worldRow - pikachu.rdel + pikachu.height + 1, MAPWIDTH)] == 0x001F)){ //bottom right
            won = 1;
        } else {
            won = 0;
        }
}