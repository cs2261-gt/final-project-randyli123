/*
Milestone 3 Comments 
What is finished:
- the main mechanics of the game 
- states
- checkpoint/flag
- animation
What needs to be done:
- Background requirement 
- Art
- Implementing sound
- Cheat
*/



#include "myLib.h"
#include "game.h"
#include "spritesheet.h"
#include "house.h"
#include "map2.h"
#include "start_background.h"
#include "pause_background.h"
#include "win_background.h"
#include "lose_background.h"


// Prototypes
// State Prototypes
void goToStart();
void start();
void goToGame();
void game();
void goToPause();
void pause();
void goToWin();
void win();
void goToLose();
void lose();
void goToGame2();
void game2();
void goToPause2();
void pause2();

// States
enum {START, GAME, PAUSE, WIN, LOSE, GAME2, PAUSE2};
int state;
int won;

// Button Variables
unsigned short buttons;
unsigned short oldButtons;

int main() {

    initialize(); 

    while(1) {

        // Update button variables
        oldButtons = buttons;
        buttons = BUTTONS;

        // State Machine
        switch(state) {

            case START:
                start();
                break;
            case GAME:
                game();
                break;
            case GAME2: // don't forget to add new states to your state machine so they run every frame of your game!
                game2();
                break;
            case PAUSE:
                pause();
                break;

            case PAUSE2:
                pause2();
                break;
            case WIN:
                win();
                break;
            case LOSE:
                lose();
                break;
        }

    }
}
// Sets up GBA
void initialize() {

    // Set up the display
    REG_DISPCTL = MODE0 | BG0_ENABLE | SPRITE_ENABLE;
    REG_BG0CNT = BG_CHARBLOCK(0) | BG_SCREENBLOCK(28) | BG_SIZE_SMALL;


    // Set up the first state
    goToStart();
}

// Sets up the game state
void goToGame() {

    // Make sure changes do not appear onscreen
    waitForVBlank();

    // Set up the house background
    DMANow(3, housePal, PALETTE, 256);
    DMANow(3, houseTiles, &CHARBLOCK[0], houseTilesLen / 2);
    DMANow(3, houseMap, &SCREENBLOCK[28], houseMapLen / 2);
    
    REG_BG0VOFF = vOff;
    REG_BG0HOFF = hOff;

    // Set up the sprites
    DMANow(3, spritesheetTiles, &CHARBLOCK[4], spritesheetTilesLen / 2);
    DMANow(3, spritesheetPal, SPRITEPALETTE, spritesheetPalLen / 2);
    hideSprites();
    DMANow(3, shadowOAM, OAM, 128 * 4);

    state = GAME;
}

// Runs every frame of the game state
void game() {

    updateGame();
    drawGame();
    // State transitions
    if (BUTTON_PRESSED(BUTTON_START)){
        REG_BG0VOFF = 0;
        REG_BG0HOFF = 0;
        goToPause();
    }
    else if (won == 1) {
        initGame2(); // recall to re-itialize all variables, you'll probably need a new initGame2 method to put pikachu where you want him on the screen
        goToGame2();
        won = 0; 
    }
    else if (BUTTON_PRESSED(BUTTON_A)) {
        initGame2(); // recall to re-itialize all variables, you'll probably need a new initGame2 method to put pikachu where you want him on the screen
        goToGame2();
    }
    else if (BUTTON_PRESSED(BUTTON_B)){
        REG_BG0VOFF = 0;
        REG_BG0HOFF = 0;
        goToLose();
    }
}

// Sets up the game state
void goToGame2() {

    // Make sure changes do not appear onscreen
    waitForVBlank();

    // Set up the house background
    DMANow(3, map2Pal, PALETTE, 256);
    DMANow(3, map2Tiles, &CHARBLOCK[0], map2TilesLen / 2);
    DMANow(3, map2Map, &SCREENBLOCK[28], map2MapLen / 2);
    
    REG_BG0VOFF = vOff;
    REG_BG0HOFF = hOff;

    // Set up the sprites
    DMANow(3, spritesheetTiles, &CHARBLOCK[4], spritesheetTilesLen / 2);
    DMANow(3, spritesheetPal, SPRITEPALETTE, spritesheetPalLen / 2);
    hideSprites();
    DMANow(3, shadowOAM, OAM, 128 * 4);

    state = GAME2;
}

// Runs every frame of the game state
void game2() {

    // you should probably have a different updateGame2 and drawGame2 method
    updateGame2();
    drawGame();
    // State transitions
    if (BUTTON_PRESSED(BUTTON_START)){
        REG_BG0VOFF = 0;
        REG_BG0HOFF = 0;
        goToPause2();
    }

    else if (won == 1) 
        goToWin();
    else if (BUTTON_PRESSED(BUTTON_A)) {
        REG_BG0VOFF = 0;
        REG_BG0HOFF = 0;
        goToWin();
    }
    else if (BUTTON_PRESSED(BUTTON_B)){
        REG_BG0VOFF = 0;
        REG_BG0HOFF = 0;
        goToLose();
    }
}
// Sets up the start state
void goToStart() {
// Load the background's palette and tiles into a desired space in memory
    DMANow(3, start_backgroundPal, PALETTE, 256);
    DMANow(3, start_backgroundTiles, &CHARBLOCK[0], start_backgroundTilesLen / 2);
    DMANow(3, start_backgroundMap, &SCREENBLOCK[28], 1024); // don't need to multiply 1024 * 4 because that is not the size of the map
    hideSprites();
    waitForVBlank();
    DMANow(3, shadowOAM, OAM, 512);
    state = START;
}

// Runs every frame of the start state
void start() {
    waitForVBlank();
    if (BUTTON_PRESSED(BUTTON_START)){
        initGame();
        goToGame();
    }
}


// Sets up the pause state
void goToPause() {
// Load the background's palette and tiles into a desired space in memory
    DMANow(3, pause_backgroundPal, PALETTE, 256);
    DMANow(3, pause_backgroundTiles, &CHARBLOCK[0], pause_backgroundTilesLen / 2);
    DMANow(3, pause_backgroundMap, &SCREENBLOCK[28], 1024); // don't need to multiply 1024 * 4 because that is not the size of the map
    hideSprites();
    waitForVBlank();
    DMANow(3, shadowOAM, OAM, 512);
    state = PAUSE;
}

// Runs every frame of the pause state
void pause() {
    waitForVBlank();
  // State transitions
    if (BUTTON_PRESSED(BUTTON_START))
        goToGame();
    else if (BUTTON_PRESSED(BUTTON_SELECT))
        goToStart();
}
// Sets up the pause state
void goToPause2() {
// Load the background's palette and tiles into a desired space in memory
    DMANow(3, pause_backgroundPal, PALETTE, 256);
    DMANow(3, pause_backgroundTiles, &CHARBLOCK[0], pause_backgroundTilesLen / 2);
    DMANow(3, pause_backgroundMap, &SCREENBLOCK[28], 1024); // don't need to multiply 1024 * 4 because that is not the size of the map
    hideSprites();
    waitForVBlank();
    DMANow(3, shadowOAM, OAM, 512);
    state = PAUSE2;
}

// Runs every frame of the pause state
void pause2() {
    waitForVBlank();
  // State transitions
    if (BUTTON_PRESSED(BUTTON_START))
        goToGame2();
    else if (BUTTON_PRESSED(BUTTON_SELECT))
        goToStart();
}
// Sets up the win state
void goToWin() {
    DMANow(3, win_backgroundPal, PALETTE, 256);
    DMANow(3, win_backgroundTiles, &CHARBLOCK[0], win_backgroundTilesLen / 2);
    DMANow(3, win_backgroundMap, &SCREENBLOCK[28], 1024); // don't need to multiply 1024 * 4 because that is not the size of the map
    hideSprites();
    waitForVBlank();
    DMANow(3, shadowOAM, OAM, 512);
    state = WIN;
}

// Runs every frame of the win state
void win() {
  // Lock the framerate to 60 fps
    waitForVBlank();
    // State transitions
    if (BUTTON_PRESSED(BUTTON_START))
        goToStart();
}

// Sets up the lose state
void goToLose() {
// Load the background's palette and tiles into a desired space in memory
    DMANow(3, lose_backgroundPal, PALETTE, 256);
    DMANow(3, lose_backgroundTiles, &CHARBLOCK[0], lose_backgroundTilesLen / 2);
    DMANow(3, lose_backgroundMap, &SCREENBLOCK[28], 1024);
    hideSprites();
    waitForVBlank();
    DMANow(3, shadowOAM, OAM, 512);
    state = LOSE;
}

// Runs every frame of the lose state
void lose() {
    waitForVBlank();
    if (BUTTON_PRESSED(BUTTON_START)){
        goToStart();
    }
}