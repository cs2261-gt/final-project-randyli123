
//{{BLOCK(collisionmap)

//======================================================================
//
//	collisionmap, 256x256@16, 
//	+ bitmap not compressed
//	Total size: 131072 = 131072
//
//	Time-stamp: 2020-04-15, 16:31:21
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_COLLISIONMAP_H
#define GRIT_COLLISIONMAP_H

#define collisionmapBitmapLen 131072
extern const unsigned short collisionmapBitmap[65536];

#endif // GRIT_COLLISIONMAP_H

//}}BLOCK(collisionmap)
