#ifndef __PICHUCRYH__
#define __PICHUCRYH__

#define PICHUCRYLEN 7500
extern const signed char pichuCry[7500];

#endif