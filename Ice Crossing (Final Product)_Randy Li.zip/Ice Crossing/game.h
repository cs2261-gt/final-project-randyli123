// Constants
#define MAPHEIGHT 256
#define MAPWIDTH 256
#define WHITE 0x7FFF
#define BLUE 0x7C00
#define BLACK 0
#define RED 0x001F


// Variables
extern int hOff;
extern int vOff;
extern OBJ_ATTR shadowOAM[128];
extern ANISPRITE pikachu;
extern ANISPRITE torch;
extern int won;

// Prototypes
void initGame();
void initGame2();
void updateGame();
void updateGame2();
void drawGame();
void initPlayer();
void updatePlayer();
void animatePlayer();
void drawPlayer();
void updatePlayer2();
void updatePlayerOnIce2();
void winCheck();
void initTorch();
void initTorch2();
void updateTorch();
void walkOnIce();
void walkOnIce2();