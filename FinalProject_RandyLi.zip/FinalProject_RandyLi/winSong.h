#ifndef __WINSONGH__
#define __WINSONGH__

#define WINSONGLEN 319692
extern const signed char winSong[319692];

#endif