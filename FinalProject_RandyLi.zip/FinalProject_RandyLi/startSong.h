#ifndef __STARTSONGH__
#define __STARTSONGH__

#define STARTSONGLEN 1731744
extern const signed char startSong[1731744];

#endif