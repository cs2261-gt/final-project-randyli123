
//{{BLOCK(map2)

//======================================================================
//
//	map2, 256x256@4, 
//	+ palette 256 entries, not compressed
//	+ 899 tiles (t|f|p reduced) not compressed
//	+ regular map (in SBBs), not compressed, 32x32 
//	Total size: 512 + 28768 + 2048 = 31328
//
//	Time-stamp: 2020-04-18, 22:31:38
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_MAP2_H
#define GRIT_MAP2_H

#define map2TilesLen 28768
extern const unsigned short map2Tiles[14384];

#define map2MapLen 2048
extern const unsigned short map2Map[1024];

#define map2PalLen 512
extern const unsigned short map2Pal[256];

#endif // GRIT_MAP2_H

//}}BLOCK(map2)
