
//{{BLOCK(collisionmap2)

//======================================================================
//
//	collisionmap2, 256x256@16, 
//	+ bitmap not compressed
//	Total size: 131072 = 131072
//
//	Time-stamp: 2020-04-17, 16:41:15
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_COLLISIONMAP2_H
#define GRIT_COLLISIONMAP2_H

#define collisionmap2BitmapLen 131072
extern const unsigned short collisionmap2Bitmap[65536];

#endif // GRIT_COLLISIONMAP2_H

//}}BLOCK(collisionmap2)
