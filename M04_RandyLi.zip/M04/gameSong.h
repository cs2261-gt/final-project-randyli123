#ifndef __GAMESONGH__
#define __GAMESONGH__

#define GAMESONGLEN 1857024
extern const signed char gameSong[1857024];

#endif