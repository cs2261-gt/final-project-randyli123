#ifndef __LEVELUPH__
#define __LEVELUPH__

#define LEVELUPLEN 22752
extern const signed char levelUp[22752];

#endif