/*
Milestone 4 Comments 
What is finished:
- Everything =)

-Randy Li
*/

#include "myLib.h"
#include "game.h"
#include "spritesheet.h"
#include "house.h"
#include "map2.h"
#include "start_background.h"
#include "pause_background.h"
#include "win_background.h"
#include "lose_background.h"
#include "trees.h"
#include "furtherTrees.h"
#include "instructions.h"
#include "sound.h"
#include "gameSong.h"
#include "levelUp.h"
#include "startSong.h"

SOUND soundA;
SOUND soundB;

// Prototypes
// State Prototypes
void goToStart();
void start();
void goToGame();
void game();
void goToPause();
void pause();
void goToWin();
void win();
void goToLose();
void lose();
void goToGame2();
void game2();
void goToPause2();
void pause2();
void goToIns();
void ins();

// States
enum {START, GAME, PAUSE, WIN, LOSE, GAME2, PAUSE2,INS};
int state;
int won;


// Button Variables
unsigned short buttons;
unsigned short oldButtons;
unsigned short phOff;

int main() {

    initialize(); 

    while(1) {

        // Update button variables
        oldButtons = buttons;
        buttons = BUTTONS;

        // State Machine
        switch(state) {

            case START:
                start();
                break;
            case GAME:
                game();
                break;
            case GAME2: // don't forget to add new states to your state machine so they run every frame of your game!
                game2();
                break;
            case PAUSE:
                pause();
                break;

            case PAUSE2:
                pause2();
                break;
            case WIN:
                win();
                break;
            case LOSE:
                lose();
                break;
            case INS:
                ins();
                break;
        }

    }
}
// Sets up GBA
void initialize() {

    // Set up the display
    REG_DISPCTL = MODE0 | BG0_ENABLE | SPRITE_ENABLE;
    REG_BG0CNT = BG_CHARBLOCK(0) | BG_SCREENBLOCK(28) | BG_SIZE_SMALL;
    REG_BG1CNT = BG_CHARBLOCK(1)|BG_SCREENBLOCK(30)|BG_SIZE_WIDE;

    setupInterrupts();
	setupSounds();

    // Set up the first state
    goToStart();
}

// Sets up the game state
void goToGame() {

    //set up display controller to enable all used bgs and sprites
    REG_DISPCTL = MODE0 | BG0_ENABLE | SPRITE_ENABLE;
    // Make sure changes do not appear onscreen
    waitForVBlank();

    // Set up the house background
    DMANow(3, housePal, PALETTE, 256);
    DMANow(3, houseTiles, &CHARBLOCK[0], houseTilesLen / 2);
    DMANow(3, houseMap, &SCREENBLOCK[28], houseMapLen / 2);
    
    REG_BG0VOFF = vOff;
    REG_BG0HOFF = hOff;

    // Set up the sprites
    DMANow(3, spritesheetTiles, &CHARBLOCK[4], spritesheetTilesLen / 2);
    DMANow(3, spritesheetPal, SPRITEPALETTE, spritesheetPalLen / 2);
    hideSprites();
    DMANow(3, shadowOAM, OAM, 128 * 4);

    state = GAME;
}

// Runs every frame of the game state
void game() {

    updateGame();
    drawGame();
    // State transitions
    if (BUTTON_PRESSED(BUTTON_START)){
        pauseSound();
        REG_BG0VOFF = 0;
        REG_BG0HOFF = 0;
        goToPause();
    }
    else if (won == 1) {
        playSoundB(levelUp, LEVELUPLEN, 0);
        initGame2(); // recall to re-itialize all variables, you'll probably need a new initGame2 method to put pikachu where you want him on the screen
        goToGame2();
        won = 0; 
    }
    // FOR TESTING PURPOSES
    // else if (BUTTON_PRESSED(BUTTON_A)) {
    //     playSoundB(levelUp, LEVELUPLEN, 0);
    //     initGame2(); // recall to re-itialize all variables, you'll probably need a new initGame2 method to put pikachu where you want him on the screen
    //     goToGame2();
    // }
}

// Sets up the game state
void goToGame2() {
    //set up display controller to enable all used bgs and sprites
    REG_DISPCTL = MODE0 | BG0_ENABLE | SPRITE_ENABLE;
    // Make sure changes do not appear onscreen
    waitForVBlank();

    // Set up the house background
    DMANow(3, map2Pal, PALETTE, 256);
    DMANow(3, map2Tiles, &CHARBLOCK[0], map2TilesLen / 2);
    DMANow(3, map2Map, &SCREENBLOCK[28], map2MapLen / 2);
    
    REG_BG0VOFF = vOff;
    REG_BG0HOFF = hOff;

    // Set up the sprites
    DMANow(3, spritesheetTiles, &CHARBLOCK[4], spritesheetTilesLen / 2);
    DMANow(3, spritesheetPal, SPRITEPALETTE, spritesheetPalLen / 2);
    hideSprites();
    DMANow(3, shadowOAM, OAM, 128 * 4);

    state = GAME2;
}

// Runs every frame of the game state
void game2() {

    // you should probably have a different updateGame2 and drawGame2 method
    updateGame2();
    drawGame();
    // State transitions
    if (BUTTON_PRESSED(BUTTON_START)){
        REG_BG0VOFF = 0;
        REG_BG0HOFF = 0;
        pauseSound();
        goToPause2();
    }

    else if (won == 1){ 
        playSoundB(levelUp, LEVELUPLEN, 0);
        goToWin();
    }
    // FOR TESTING PURPOSES
    // else if (BUTTON_PRESSED(BUTTON_A)) {
    //     REG_BG0VOFF = 0;
    //     REG_BG0HOFF = 0;
    //     playSoundB(levelUp, LEVELUPLEN, 0);
    //     goToWin();
    // }
}
// Sets up the start state
void goToStart() {
// Load the background's palette and tiles into a desired space in memory
    DMANow(3, start_backgroundPal, PALETTE, 256);
    DMANow(3, start_backgroundTiles, &CHARBLOCK[0], start_backgroundTilesLen / 2);
    DMANow(3, start_backgroundMap, &SCREENBLOCK[28], start_backgroundMapLen / 2); // don't need to multiply 1024 * 4 because that is not the size of the map
    hideSprites();
    waitForVBlank();
    DMANow(3, shadowOAM, OAM, 512);
    state = START;
    playSoundA(startSong, STARTSONGLEN, 1);
}

// Runs every frame of the start state
void start() {
    waitForVBlank();
    if (BUTTON_PRESSED(BUTTON_START)){
         stopSound();
		 playSoundA(gameSong, GAMESONGLEN, 1);
		 playSoundB(levelUp, LEVELUPLEN, 0);

        initGame();
        goToGame();
    }
    else if (BUTTON_PRESSED(BUTTON_A)){
        goToIns();
    }
}


// Sets up the pause state
void goToPause() {
// Load the background's palette and tiles into a desired space in memory

    REG_DISPCTL = MODE0 | BG1_ENABLE | BG0_ENABLE;

    REG_BG0CNT = BG_CHARBLOCK(0) | BG_SCREENBLOCK(28) | BG_SIZE_WIDE;
    DMANow(3,treesTiles, &CHARBLOCK[0], treesTilesLen/2);
    DMANow(3,treesMap, &SCREENBLOCK[28], treesMapLen/2);

    REG_BG1CNT = BG_CHARBLOCK(1)|BG_SCREENBLOCK(30)|BG_SIZE_SMALL;
    DMANow(3,furtherTreesPal, PALETTE, furtherTreesPalLen/2);
    DMANow(3,furtherTreesTiles, &CHARBLOCK[1], furtherTreesTilesLen/2);
    DMANow(3,furtherTreesMap, &SCREENBLOCK[30], furtherTreesMapLen/2);

    
    phOff = 0;
    buttons = BUTTONS;
    hideSprites();
    waitForVBlank();
    DMANow(3, shadowOAM, OAM, 512);
    state = PAUSE;
}

// Runs every frame of the pause state
void pause() {
    waitForVBlank();
  // State transitions
   // Scroll the background
    if(BUTTON_HELD(BUTTON_LEFT)) {
        phOff--;
    }
    else if(BUTTON_HELD(BUTTON_RIGHT)) {
        phOff++;
    }
    else if (BUTTON_PRESSED(BUTTON_START)) {
        unpauseSound();
        goToGame();
    }
    else if (BUTTON_PRESSED(BUTTON_SELECT))
        goToStart();

    REG_BG0HOFF = phOff;
    REG_BG1HOFF = phOff/2;
}
// Sets up the pause state
void goToPause2() {
    // Load the background's palette and tiles into a desired space in memory
     REG_DISPCTL = MODE0 | BG1_ENABLE | BG0_ENABLE;

    REG_BG0CNT = BG_CHARBLOCK(0) | BG_SCREENBLOCK(28) | BG_SIZE_WIDE;
    DMANow(3,treesTiles, &CHARBLOCK[0], treesTilesLen/2);
    DMANow(3,treesMap, &SCREENBLOCK[28], treesMapLen/2);

    REG_BG1CNT = BG_CHARBLOCK(1)|BG_SCREENBLOCK(30)|BG_SIZE_SMALL;
    DMANow(3,furtherTreesPal, PALETTE, furtherTreesPalLen/2);
    DMANow(3,furtherTreesTiles, &CHARBLOCK[1], furtherTreesTilesLen/2);
    DMANow(3,furtherTreesMap, &SCREENBLOCK[30], furtherTreesMapLen/2);

    
    phOff = 0;
    buttons = BUTTONS;
    hideSprites();
    waitForVBlank();
    DMANow(3, shadowOAM, OAM, 512);
    state = PAUSE2;
}

// Runs every frame of the pause state
void pause2() {
 waitForVBlank();
  // State transitions
   // Scroll the background
    if(BUTTON_HELD(BUTTON_LEFT)) {
        phOff--;
    }
    else if(BUTTON_HELD(BUTTON_RIGHT)) {
        phOff++;
    }
    else if (BUTTON_PRESSED(BUTTON_START)) {
        unpauseSound();
        goToGame2();
    }
    else if (BUTTON_PRESSED(BUTTON_SELECT))
        goToStart();

    REG_BG0HOFF = phOff;
    REG_BG1HOFF = phOff/2;
}
// Sets up the win state
void goToWin() {
    REG_BG0VOFF = 0;
    REG_BG0HOFF = 0;

    DMANow(3, win_backgroundPal, PALETTE, 256);
    DMANow(3, win_backgroundTiles, &CHARBLOCK[0], win_backgroundTilesLen / 2);
    DMANow(3, win_backgroundMap, &SCREENBLOCK[28], 1024); // don't need to multiply 1024 * 4 because that is not the size of the map
    hideSprites();
    waitForVBlank();
    DMANow(3, shadowOAM, OAM, 512);
    state = WIN;
}

// Runs every frame of the win state
void win() {
  // Lock the framerate to 60 fps
    waitForVBlank();
    // State transitions
    if (BUTTON_PRESSED(BUTTON_START))
        goToStart();
}

// Sets up the lose state
void goToLose() {
// Load the background's palette and tiles into a desired space in memory
    DMANow(3, lose_backgroundPal, PALETTE, 256);
    DMANow(3, lose_backgroundTiles, &CHARBLOCK[0], lose_backgroundTilesLen / 2);
    DMANow(3, lose_backgroundMap, &SCREENBLOCK[28], 1024);
    hideSprites();
    waitForVBlank();
    DMANow(3, shadowOAM, OAM, 512);
    state = LOSE;
}

// Runs every frame of the lose state
void lose() {
    waitForVBlank();
    if (BUTTON_PRESSED(BUTTON_START)){
        goToStart();
    }
}
// Sets up the lose state
void goToIns() {
// Load the background's palette and tiles into a desired space in memory
    DMANow(3, instructionsPal, PALETTE, 256);
    DMANow(3, instructionsTiles, &CHARBLOCK[0], instructionsTilesLen / 2);
    DMANow(3, instructionsMap, &SCREENBLOCK[28], 1024);
    hideSprites();
    waitForVBlank();
    DMANow(3, shadowOAM, OAM, 512);
    state = INS;
}

// Runs every frame of the lose state
void ins() {
    waitForVBlank();
    if (BUTTON_PRESSED(BUTTON_START)){
        goToStart();
    }
}