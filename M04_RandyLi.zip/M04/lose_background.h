
//{{BLOCK(lose_background)

//======================================================================
//
//	lose_background, 256x256@4, 
//	+ palette 256 entries, not compressed
//	+ 60 tiles (t|f|p reduced) not compressed
//	+ regular map (flat), not compressed, 32x32 
//	Total size: 512 + 1920 + 2048 = 4480
//
//	Time-stamp: 2020-04-05, 16:13:19
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_LOSE_BACKGROUND_H
#define GRIT_LOSE_BACKGROUND_H

#define lose_backgroundTilesLen 1920
extern const unsigned short lose_backgroundTiles[960];

#define lose_backgroundMapLen 2048
extern const unsigned short lose_backgroundMap[1024];

#define lose_backgroundPalLen 512
extern const unsigned short lose_backgroundPal[256];

#endif // GRIT_LOSE_BACKGROUND_H

//}}BLOCK(lose_background)
